<?php
class Config {
    public static $db = [
        "host" => "localhost",
        "port" => "5432",
        "user" => "qvw9pv",
        "pass" => "SiS9h2_cl0H0",
        "database" => "qvw9pv"
    ];
}
