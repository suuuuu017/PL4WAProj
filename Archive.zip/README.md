# PL4WAProj

reference: https://stackoverflow.com/questions/16562577/how-can-i-make-a-button-redirect-my-page-to-another-page
https://developer.mozilla.org/en-US/docs/Learn/CSS/Howto/Make_box_transparent

https://stackoverflow.com/questions/16670931/hide-scroll-bar-but-while-still-being-able-to-scroll 